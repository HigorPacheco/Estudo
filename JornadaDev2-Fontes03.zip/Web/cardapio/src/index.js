import React from 'react';
import ReactDOM from 'react-dom';
import Pedidos from './pages/pedidos';
import './styles/global.css';
   
ReactDOM.render(<Pedidos />,
document.getElementById('root'));
